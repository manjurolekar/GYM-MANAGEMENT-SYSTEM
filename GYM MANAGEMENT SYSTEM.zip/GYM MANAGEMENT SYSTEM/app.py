from flask import Flask, render_template, request, redirect, url_for
import pyodbc

app = Flask(__name__)

# ================= SQL SERVER CONNECTION =================
conn = pyodbc.connect(
    'DRIVER={SQL Server};'
    'SERVER=DESKTOP-MKGPS-1;'
    'DATABASE=GymDB;'
    'UID=sa;'        # SQL username
    'PWD=P@ssw0rd;'          # SQL password
)
cursor = conn.cursor()

# ================= HOME PAGE =================
@app.route('/')
def index():
    cursor.execute("SELECT * FROM Membership")
    plans = cursor.fetchall()
    return render_template('index.html', plans=plans)

# ================= ADD MEMBERSHIP PLAN =================
@app.route('/add_plan', methods=['POST'])
def add_plan():
    plan = request.form['plan']
    fees = request.form['fees']
    slots = request.form['slots']

    cursor.execute(
        "INSERT INTO Membership (Plan_Name, Fees, Slots) VALUES (?, ?, ?)",
        (plan, fees, slots)
    )
    conn.commit()
    return redirect(url_for('index'))

# ================= ASSIGN MEMBER (ISSUE LOGIC) =================
@app.route('/assign_member', methods=['POST'])
def assign_member():
    member = request.form['member']
    phone = request.form['phone']
    plan = request.form['plan']

    # Reduce slot by 1
    cursor.execute(
        "UPDATE Membership SET Slots = Slots - 1 WHERE Plan_Name = ?",
        (plan,)
    )

    # Delete plan if slots become 0
    cursor.execute(
        "DELETE FROM Membership WHERE Slots <= 0"
    )

    # Insert member record
    cursor.execute(
        "INSERT INTO Member (Member_Name, Phone, Plan_Name) VALUES (?, ?, ?)",
        (member, phone, plan)
    )

    conn.commit()
    return redirect(url_for('index'))

# ================= RUN APPLICATION =================
if __name__ == '__main__':
    app.run(debug=True)
