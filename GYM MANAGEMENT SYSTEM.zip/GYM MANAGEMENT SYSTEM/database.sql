/* ================================
   CREATE DATABASE
================================ */
CREATE DATABASE GymDB;
GO

USE GymDB;
GO

/* ================================
   MEMBERSHIP TABLE
   (Like Blood Stock)
================================ */
CREATE TABLE Membership (
    Plan_ID INT IDENTITY(1,1) PRIMARY KEY,
    Plan_Name VARCHAR(30) NOT NULL,
    Fees INT NOT NULL,
    Slots INT NOT NULL
);
GO

/* ================================
   MEMBER TABLE
   (Like Blood Issue)
================================ */
CREATE TABLE Member (
    Member_ID INT IDENTITY(1,1) PRIMARY KEY,
    Member_Name VARCHAR(30) NOT NULL,
    Phone VARCHAR(15),
    Plan_Name VARCHAR(30)
);
GO

/* ================================
   INSERT SAMPLE MEMBERSHIP PLANS
================================ */
INSERT INTO Membership (Plan_Name, Fees, Slots) VALUES
('Monthly', 1500, 5),
('Quarterly', 4000, 3),
('Yearly', 12000, 2);
GO

/* ================================
   VIEW DATA
================================ */
SELECT * FROM Membership;
SELECT * FROM Member;
GO

/* ================================
   ASSIGN MEMBER (ISSUE LOGIC)
   Reduce slot by 1
================================ */
UPDATE Membership
SET Slots = Slots - 1
WHERE Plan_Name = 'Monthly';
GO

/* ================================
   AUTO DELETE PLAN IF SLOT = 0
================================ */
DELETE FROM Membership
WHERE Slots <= 0;
GO

/* ================================
   ADD MEMBER RECORD
================================ */
INSERT INTO Member (Member_Name, Phone, Plan_Name)
VALUES ('Rahul', '9876543210', 'Monthly');
GO


SELECT * FROM Membership;
SELECT * FROM Member;
GO